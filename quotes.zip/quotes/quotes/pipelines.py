from scrapy.exceptions import DropItem


class QuotesPipeline:
    def process_item(self, item, spider):
        return item


class BooksPrice(object):
    def process_item(self, item, spider):
        price = item['price'].replace('£', '')
        if float(price)>50:
            item['price'] = 'Expensive'
        else:
            item['price'] = price
        return item

class CheckAsViable(object):
    def process_item(self, item, spider):
        if item['price']!= 'Expensive':
            print("\r\rBook Found:\n")
            print("title -> "+item['title'])
            print("price -> "+item['price'])
            print("imageurl -> "+item['imageurl'])
            print("bookurl -> "+item['bookurl'])
        else:
            raise DropItem()
        return item