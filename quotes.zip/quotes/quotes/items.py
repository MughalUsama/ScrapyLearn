# Define here the models for your scraped items
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/items.html

import scrapy
from scrapy.loader.processors import MapCompose


def add_link(url):
    return 'http://books.toscrape.com/'+url.replace('../', '')


class QuotesItem(scrapy.Item):
    # define the fields for your item here like:
    # name = scrapy.Field()
    quote = scrapy.Field()
    author = scrapy.Field()
    tags = scrapy.Field()


class BooksItem(scrapy.Item):
    title = scrapy.Field()
    price = scrapy.Field()
    imageurl = scrapy.Field(input_processor=MapCompose(add_link))
    bookurl = scrapy.Field(input_processor=MapCompose(add_link))
